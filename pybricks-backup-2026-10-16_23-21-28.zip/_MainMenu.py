#This is the main menu code for running multiple missions on the Spike Prime Hub.
#This code is taken directly from the Pybricks tutorial

from pybricks.tools import hub_menu

# Make a menu to choose a letter. You can also use numbers.
selected = hub_menu("1", "2", "3", "4", "5", "6", "7", "8")

# Based on the selection, run a program.
if selected == "1":
    import Mission_30Flip_the_Rock
elif selected == "2":
    import Mission_8Tangled
elif selected == "3":
    import biocentric_architecture
elif selected == "4":
    import Zoe2
elif selected == "5":
    import drone_survey
elif selected == "6":
    import keystone_species
elif selected == "7":
    import KEEP_ForestElder_Sloane_SecondCode
elif selected == "8":
    import leaf_cutter_frenzy